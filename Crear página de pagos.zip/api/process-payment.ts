import type { VercelRequest, VercelResponse } from '@vercel/node';

interface PaymentRequest {
  processor: 'stripe' | 'paypal' | 'braintree' | 'square';
  cardData: {
    cardNumber: string;
    cardName: string;
    expiryMonth: string;
    expiryYear: string;
    cvv: string;
    amount: string;
  };
}

export default async function handler(
  req: VercelRequest,
  res: VercelResponse,
) {
  // Solo permitir POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { processor, cardData } = req.body as PaymentRequest;

  try {
    let result;

    switch (processor) {
      case 'stripe':
        result = await processStripePayment(cardData);
        break;
      case 'paypal':
        result = await processPayPalPayment(cardData);
        break;
      case 'braintree':
        result = await processBraintreePayment(cardData);
        break;
      case 'square':
        result = await processSquarePayment(cardData);
        break;
      default:
        return res.status(400).json({ error: 'Invalid processor' });
    }

    return res.status(200).json(result);
  } catch (error: any) {
    console.error('Payment error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Error al procesar pago',
      error: 'SERVER_ERROR',
    });
  }
}

// Procesar pago con Stripe
async function processStripePayment(cardData: any) {
  const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;

  if (!STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY no configurada');
  }

  // Crear Payment Intent
  const response = await fetch('https://api.stripe.com/v1/payment_intents', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      'amount': Math.round(parseFloat(cardData.amount) * 100).toString(),
      'currency': 'usd',
      'payment_method_data[type]': 'card',
      'payment_method_data[card][number]': cardData.cardNumber.replace(/\s/g, ''),
      'payment_method_data[card][exp_month]': cardData.expiryMonth,
      'payment_method_data[card][exp_year]': '20' + cardData.expiryYear,
      'payment_method_data[card][cvc]': cardData.cvv,
      'payment_method_data[billing_details][name]': cardData.cardName,
      'confirm': 'true',
    }),
  });

  const result = await response.json();

  if (!response.ok || result.error) {
    return {
      processor: 'Stripe',
      status: 'error',
      message: result.error?.message || 'Error al procesar el pago',
      error: result.error?.code || 'PAYMENT_FAILED',
      timestamp: Date.now(),
    };
  }

  return {
    processor: 'Stripe',
    status: 'success',
    message: `Pago procesado - $${cardData.amount} USD`,
    transactionId: result.id,
    timestamp: Date.now(),
  };
}

// Procesar pago con PayPal
async function processPayPalPayment(cardData: any) {
  const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
  const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET;

  if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
    throw new Error('PayPal credentials no configuradas');
  }

  // Obtener access token
  const authResponse = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64'),
    },
    body: 'grant_type=client_credentials',
  });

  if (!authResponse.ok) {
    const error = await authResponse.json();
    return {
      processor: 'PayPal',
      status: 'error',
      message: error.error_description || 'Error de autenticación',
      error: error.error || 'AUTH_ERROR',
      timestamp: Date.now(),
    };
  }

  const { access_token } = await authResponse.json();

  // Crear orden
  const orderResponse = await fetch('https://api-m.sandbox.paypal.com/v2/checkout/orders', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${access_token}`,
    },
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [{
        amount: {
          currency_code: 'USD',
          value: cardData.amount,
        },
      }],
      payment_source: {
        card: {
          number: cardData.cardNumber.replace(/\s/g, ''),
          expiry: `20${cardData.expiryYear}-${cardData.expiryMonth}`,
          security_code: cardData.cvv,
          name: cardData.cardName,
        },
      },
    }),
  });

  const result = await orderResponse.json();

  if (!orderResponse.ok) {
    return {
      processor: 'PayPal',
      status: 'error',
      message: result.message || result.details?.[0]?.description || 'Error al procesar',
      error: result.name || 'PAYMENT_FAILED',
      timestamp: Date.now(),
    };
  }

  return {
    processor: 'PayPal',
    status: 'success',
    message: `Pago autorizado - $${cardData.amount} USD`,
    transactionId: result.id,
    timestamp: Date.now(),
  };
}

// Procesar pago con Braintree
async function processBraintreePayment(cardData: any) {
  // Braintree requiere SDK, por ahora devolver demo
  return {
    processor: 'Braintree',
    status: 'success',
    message: `Transacción procesada - $${cardData.amount} USD (requiere SDK)`,
    transactionId: 'bt_' + Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
  };
}

// Procesar pago con Square
async function processSquarePayment(cardData: any) {
  // Square requiere SDK específico, por ahora devolver demo
  return {
    processor: 'Square',
    status: 'success',
    message: `Pago completado - $${cardData.amount} USD (requiere SDK)`,
    transactionId: 'sq_' + Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
  };
}
