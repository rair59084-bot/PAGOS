import { useState } from 'react';
import { PaymentForm, CardData } from './components/payment-form';
import { ApiConfiguration, ApiConfig } from './components/api-config';
import { PaymentResults } from './components/payment-results';
import { processPaymentThroughAllProcessors, PaymentResult } from './components/payment-service';
import { toast, Toaster } from 'sonner';
import { CreditCard, Settings as SettingsIcon, Lock } from 'lucide-react';

export default function App() {
  const [apiConfig, setApiConfig] = useState<ApiConfig>({
    stripe: { publishableKey: '', secretKey: '' },
    braintree: { merchantId: '', publicKey: '', privateKey: '' },
    square: { applicationId: '', accessToken: '', locationId: '' },
    paypal: { clientId: '', clientSecret: '' }
  });

  const [paymentResults, setPaymentResults] = useState<PaymentResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState('config');
  const [lastCardData, setLastCardData] = useState<CardData | undefined>();

  const handlePaymentSubmit = async (cardData: CardData) => {
    // Check if at least one processor is configured
    const hasConfiguredProcessor = Object.entries(apiConfig).some(([key, value]) => {
      if (!value) return false;
      return Object.values(value).every(v => v && v.trim() !== '');
    });

    if (!hasConfiguredProcessor) {
      toast.error('Debes configurar al menos 1 procesador de pago');
      setActiveTab('config');
      return;
    }

    setIsProcessing(true);
    setPaymentResults([]);
    setLastCardData(cardData);
    setActiveTab('results');

    try {
      await processPaymentThroughAllProcessors(
        cardData,
        apiConfig,
        (result) => {
          setPaymentResults(prev => {
            const existing = prev.findIndex(r => r.processor === result.processor);
            if (existing >= 0) {
              const updated = [...prev];
              updated[existing] = result;
              return updated;
            }
            return [...prev, result];
          });
        }
      );

      const successCount = paymentResults.filter(r => r.status === 'success').length;
      if (successCount > 0) {
        toast.success(`Pago procesado en ${successCount} procesador${successCount > 1 ? 'es' : ''}`);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Error al procesar pago');
    } finally {
      setIsProcessing(false);
    }
  };

  const configuredCount = Object.entries(apiConfig).filter(([key, value]) => {
    if (!value) return false;
    return Object.values(value).every(v => v && v.trim() !== '');
  }).length;

  return (
    <>
      <Toaster position="top-right" richColors />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-8 px-4">
        <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Sistema Multi-Procesador de Pagos
          </h1>
          <p className="text-gray-600">
            Procesa pagos simultáneamente a través de múltiples plataformas
          </p>
        </div>

        <div className="space-y-6">
          {/* Tab Navigation */}
          <div className="flex gap-2 p-1 bg-white rounded-lg shadow-sm border border-gray-200">
            <button
              onClick={() => setActiveTab('config')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md text-sm font-medium transition-all ${
                activeTab === 'config'
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <SettingsIcon className="w-4 h-4" />
              Configuración APIs
              {configuredCount > 0 && (
                <span className="ml-1 px-2 py-0.5 bg-green-500 text-white text-xs rounded-full">
                  {configuredCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('payment')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md text-sm font-medium transition-all ${
                activeTab === 'payment'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Pago
            </button>
            <button
              onClick={() => setActiveTab('results')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md text-sm font-medium transition-all ${
                activeTab === 'results'
                  ? 'bg-green-600 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              Resultados
              {paymentResults.length > 0 && (
                <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                  activeTab === 'results' ? 'bg-white text-gray-900' : 'bg-gray-200 text-gray-700'
                }`}>
                  {paymentResults.length}
                </span>
              )}
            </button>
          </div>

          {/* Tab Content */}
          {activeTab === 'config' && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <ApiConfiguration config={apiConfig} onChange={setApiConfig} />
            </div>
          )}

          {activeTab === 'payment' && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <PaymentForm onSubmit={handlePaymentSubmit} isProcessing={isProcessing} />
            </div>
          )}

          {activeTab === 'results' && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              {paymentResults.length === 0 && !isProcessing ? (
                <div className="text-center py-12 text-gray-500">
                  <CreditCard className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p>No hay resultados aún</p>
                  <p className="text-sm">Procesa un pago para ver los resultados aquí</p>
                </div>
              ) : (
                <PaymentResults
                  results={paymentResults}
                  isProcessing={isProcessing}
                  cardData={lastCardData}
                />
              )}
            </div>
          )}
        </div>

        <div className="mt-8 p-6 bg-white rounded-lg shadow-lg">
          <h3 className="font-semibold mb-4">Procesadores Disponibles</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['Stripe', 'Braintree', 'Square', 'PayPal'].map((processor) => {
              const key = processor.toLowerCase() as keyof ApiConfig;
              const isConfigured = apiConfig[key] && Object.values(apiConfig[key]!).every(v => v && v.trim() !== '');

              return (
                <div
                  key={processor}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    isConfigured
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="font-semibold mb-1">{processor}</div>
                  <div className={`text-sm ${isConfigured ? 'text-green-600' : 'text-gray-500'}`}>
                    {isConfigured ? '✓ Configurado' : '○ Sin configurar'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-6 space-y-3">
          <div className="p-4 bg-green-50 border border-green-300 rounded-lg">
            <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
              ✅ Sistema con Backend REAL
            </h4>
            <p className="text-sm text-green-800 mb-2">
              Este sistema ahora tiene un backend serverless que procesa pagos REALES a través de Stripe y PayPal.
            </p>
            <p className="text-sm text-green-800">
              <strong>Para usar pagos reales:</strong> Lee el archivo <code className="bg-green-100 px-1 rounded font-mono">INSTRUCCIONES-DESPLIEGUE.md</code> que está en tu proyecto.
              Te explica paso a paso cómo desplegarlo gratis en Vercel.
            </p>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">🚀 Cómo hacer funcionar los pagos REALES</h4>
            <ol className="text-sm text-blue-800 space-y-2 list-decimal list-inside">
              <li>Sube tu proyecto a <strong>GitHub</strong></li>
              <li>Crea una cuenta gratis en <strong>Vercel.com</strong></li>
              <li>Conecta tu repositorio de GitHub con Vercel</li>
              <li>Agrega tus claves de PayPal/Stripe en las <strong>Environment Variables</strong> de Vercel</li>
              <li>Haz clic en <strong>Deploy</strong></li>
              <li>¡Listo! Tendrás una URL donde los pagos funcionan de verdad</li>
            </ol>
            <p className="text-xs text-blue-700 mt-2 italic">
              📄 Instrucciones detalladas en <strong>INSTRUCCIONES-DESPLIEGUE.md</strong>
            </p>
          </div>

          <div className="p-4 bg-yellow-50 border border-yellow-300 rounded-lg">
            <h4 className="font-semibold text-yellow-900 mb-2">⚠️ Modo Local (Sin Deploy)</h4>
            <p className="text-sm text-yellow-800 mb-2">
              Si estás probando localmente <strong>sin desplegar</strong>, los pagos NO funcionarán porque el backend
              serverless solo funciona en Vercel/producción.
            </p>
            <p className="text-sm text-yellow-800">
              <strong>Solución:</strong> Despliega en Vercel (gratis) siguiendo las instrucciones, o verás errores de conexión.
            </p>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="font-semibold text-purple-900 mb-2">🧪 Tarjetas de Prueba</h4>
            <p className="text-sm text-purple-800 mb-2">
              Usa estas tarjetas de prueba con tus credenciales de <strong>Sandbox</strong>:
            </p>
            <ul className="text-sm text-purple-800 space-y-1">
              <li><code className="bg-purple-100 px-2 py-1 rounded font-mono">4532 1234 5678 9010</code> - Visa exitosa</li>
              <li><code className="bg-purple-100 px-2 py-1 rounded font-mono">5425 2334 3010 9903</code> - Mastercard exitosa</li>
              <li>Cualquier fecha futura (12/25) y CVV (123)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}