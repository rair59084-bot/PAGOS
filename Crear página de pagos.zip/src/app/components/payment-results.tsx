import { CheckCircle2, XCircle, Loader2, Clock, CreditCard } from 'lucide-react';
import { PaymentResult } from './payment-service';
import { CardData } from './payment-form';

interface PaymentResultsProps {
  results: PaymentResult[];
  isProcessing: boolean;
  cardData?: CardData;
}

export function PaymentResults({ results, isProcessing, cardData }: PaymentResultsProps) {
  if (results.length === 0 && !isProcessing) {
    return null;
  }

  const successCount = results.filter(r => r.status === 'success').length;
  const errorCount = results.filter(r => r.status === 'error').length;
  const processingCount = results.filter(r => r.status === 'processing').length;

  const maskCardNumber = (cardNumber: string) => {
    const cleaned = cardNumber.replace(/\s/g, '');
    const lastFour = cleaned.slice(-4);
    return `•••• •••• •••• ${lastFour}`;
  };

  const successPlatforms = results.filter(r => r.status === 'success').map(r => r.processor);
  const failedPlatforms = results.filter(r => r.status === 'error').map(r => r.processor);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className={`p-3 rounded-lg ${
          isProcessing ? 'bg-blue-100' :
          successCount > 0 ? 'bg-green-100' : 'bg-red-100'
        }`}>
          {isProcessing ? (
            <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
          ) : successCount > 0 ? (
            <CheckCircle2 className="w-6 h-6 text-green-600" />
          ) : (
            <XCircle className="w-6 h-6 text-red-600" />
          )}
        </div>
        <div>
          <h2 className="text-2xl font-semibold">
            {isProcessing ? 'Procesando Pagos' : 'Resultados de Pago'}
          </h2>
          <p className="text-sm text-gray-600">
            {isProcessing
              ? `Procesando en ${processingCount} procesador${processingCount > 1 ? 'es' : ''}...`
              : `${successCount} exitoso${successCount !== 1 ? 's' : ''}, ${errorCount} fallido${errorCount !== 1 ? 's' : ''}`
            }
          </p>
        </div>
      </div>

      {/* Card Information Summary */}
      {cardData && (
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              <h3 className="font-semibold">Datos de la Tarjeta</h3>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">${cardData.amount}</div>
              <div className="text-xs text-gray-400">USD</div>
            </div>
          </div>

          <div className="space-y-2 mb-4">
            <div className="text-lg font-mono tracking-wider">
              {maskCardNumber(cardData.cardNumber)}
            </div>
            <div className="flex items-center justify-between text-sm">
              <div>
                <div className="text-xs text-gray-400">TITULAR</div>
                <div className="font-medium">{cardData.cardName}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-400">VENCE</div>
                <div className="font-medium">{cardData.expiryMonth}/{cardData.expiryYear}</div>
              </div>
            </div>
          </div>

          {/* Platform Summary */}
          <div className="pt-4 border-t border-gray-700">
            <div className="text-xs text-gray-400 mb-2">PROCESADORES UTILIZADOS</div>
            <div className="space-y-1">
              {successPlatforms.length > 0 && (
                <div className="flex items-center gap-2 text-xs">
                  <CheckCircle2 className="w-3 h-3 text-green-400 flex-shrink-0" />
                  <span className="text-green-300">
                    Exitoso: {successPlatforms.join(', ')}
                  </span>
                </div>
              )}
              {failedPlatforms.length > 0 && (
                <div className="flex items-center gap-2 text-xs">
                  <XCircle className="w-3 h-3 text-red-400 flex-shrink-0" />
                  <span className="text-red-300">
                    Fallido: {failedPlatforms.join(', ')}
                  </span>
                </div>
              )}
              {processingCount > 0 && (
                <div className="flex items-center gap-2 text-xs">
                  <Loader2 className="w-3 h-3 text-blue-400 animate-spin flex-shrink-0" />
                  <span className="text-blue-300">
                    Procesando en {processingCount} plataforma{processingCount > 1 ? 's' : ''}...
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {results.map((result, index) => (
          <div
            key={`${result.processor}-${index}`}
            className={`border-2 rounded-lg p-4 transition-all ${
              result.status === 'success'
                ? 'border-green-500 bg-green-50'
                : result.status === 'error'
                ? 'border-red-500 bg-red-50'
                : 'border-blue-500 bg-blue-50'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <div className="mt-1">
                  {result.status === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : result.status === 'error' ? (
                    <XCircle className="w-5 h-5 text-red-600" />
                  ) : (
                    <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{result.processor}</h3>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        result.status === 'success'
                          ? 'bg-green-200 text-green-800'
                          : result.status === 'error'
                          ? 'bg-red-200 text-red-800'
                          : 'bg-blue-200 text-blue-800'
                      }`}
                    >
                      {result.status === 'success'
                        ? 'EXITOSO'
                        : result.status === 'error'
                        ? 'FALLIDO'
                        : 'PROCESANDO'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 mb-2">{result.message}</p>
                  {result.transactionId && (
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <span className="font-medium">ID Transacción:</span>
                      <code className="bg-white px-2 py-1 rounded border border-gray-300">
                        {result.transactionId}
                      </code>
                    </div>
                  )}
                  {result.error && (
                    <div className="flex items-center gap-2 text-xs text-red-700 mt-2">
                      <span className="font-medium">Error:</span>
                      <code className="bg-red-100 px-2 py-1 rounded border border-red-300">
                        {result.error}
                      </code>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs text-gray-500 ml-4">
                <Clock className="w-3 h-3" />
                <span>{new Date(result.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!isProcessing && results.length > 0 && (
        <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <h3 className="font-semibold mb-2">Resumen de Procesamiento</h3>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-gray-600">Total Procesadores</div>
              <div className="text-2xl font-bold">{results.length}</div>
            </div>
            <div>
              <div className="text-green-600">Exitosos</div>
              <div className="text-2xl font-bold text-green-600">{successCount}</div>
            </div>
            <div>
              <div className="text-red-600">Fallidos</div>
              <div className="text-2xl font-bold text-red-600">{errorCount}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
