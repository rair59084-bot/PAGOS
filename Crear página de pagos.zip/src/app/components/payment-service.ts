import { CardData } from './payment-form';
import { ApiConfig } from './api-config';

export interface PaymentResult {
  processor: string;
  status: 'success' | 'error' | 'processing';
  message: string;
  transactionId?: string;
  error?: string;
  timestamp: number;
}

// Generate random ID
function generateId(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).substr(2, 9)}`;
}

// Process Stripe payment via backend API
async function processStripePayment(
  cardData: CardData,
  config: ApiConfig['stripe']
): Promise<PaymentResult> {
  try {
    if (!config?.publishableKey || !config?.secretKey) {
      throw new Error('Stripe API keys no configuradas');
    }

    // Llamar al backend serverless
    const response = await fetch('/api/process-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        processor: 'stripe',
        cardData,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        processor: 'Stripe',
        status: 'error',
        message: result.message || 'Error al procesar el pago',
        error: result.error || 'PAYMENT_FAILED',
        timestamp: Date.now(),
      };
    }

    return {
      ...result,
      processor: 'Stripe',
    };

  } catch (error: any) {
    return {
      processor: 'Stripe',
      status: 'error',
      message: error.message || 'Error al conectar con el servidor de pagos',
      error: 'SERVER_ERROR',
      timestamp: Date.now(),
    };
  }
}

// Process Braintree payment via backend API
async function processBraintreePayment(
  cardData: CardData,
  config: ApiConfig['braintree']
): Promise<PaymentResult> {
  try {
    if (!config?.merchantId || !config?.publicKey || !config?.privateKey) {
      throw new Error('Braintree API keys no configuradas');
    }

    // Llamar al backend serverless
    const response = await fetch('/api/process-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        processor: 'braintree',
        cardData,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        processor: 'Braintree',
        status: 'error',
        message: result.message || 'Error al procesar el pago',
        error: result.error || 'PAYMENT_FAILED',
        timestamp: Date.now(),
      };
    }

    return {
      ...result,
      processor: 'Braintree',
    };

  } catch (error: any) {
    return {
      processor: 'Braintree',
      status: 'error',
      message: error.message || 'Error al conectar con el servidor de pagos',
      error: 'SERVER_ERROR',
      timestamp: Date.now(),
    };
  }
}

// Process Square payment via backend API
async function processSquarePayment(
  cardData: CardData,
  config: ApiConfig['square']
): Promise<PaymentResult> {
  try {
    if (!config?.applicationId || !config?.accessToken || !config?.locationId) {
      throw new Error('Square API keys no configuradas');
    }

    // Llamar al backend serverless
    const response = await fetch('/api/process-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        processor: 'square',
        cardData,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        processor: 'Square',
        status: 'error',
        message: result.message || 'Error al procesar el pago',
        error: result.error || 'PAYMENT_FAILED',
        timestamp: Date.now(),
      };
    }

    return {
      ...result,
      processor: 'Square',
    };

  } catch (error: any) {
    return {
      processor: 'Square',
      status: 'error',
      message: error.message || 'Error al conectar con el servidor de pagos',
      error: 'SERVER_ERROR',
      timestamp: Date.now(),
    };
  }
}

// Process PayPal payment via backend API
async function processPayPalPayment(
  cardData: CardData,
  config: ApiConfig['paypal']
): Promise<PaymentResult> {
  try {
    if (!config?.clientId || !config?.clientSecret) {
      throw new Error('PayPal API keys no configuradas');
    }

    // Llamar al backend serverless
    const response = await fetch('/api/process-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        processor: 'paypal',
        cardData,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      return {
        processor: 'PayPal',
        status: 'error',
        message: result.message || 'Error al procesar el pago',
        error: result.error || 'PAYMENT_FAILED',
        timestamp: Date.now(),
      };
    }

    return {
      ...result,
      processor: 'PayPal',
    };

  } catch (error: any) {
    return {
      processor: 'PayPal',
      status: 'error',
      message: error.message || 'Error al conectar con el servidor de pagos',
      error: 'SERVER_ERROR',
      timestamp: Date.now(),
    };
  }
}

export async function processPaymentThroughAllProcessors(
  cardData: CardData,
  apiConfig: ApiConfig,
  onUpdate: (result: PaymentResult) => void
): Promise<PaymentResult[]> {
  const processors: Array<{
    name: keyof ApiConfig;
    process: (cardData: CardData, config: any) => Promise<PaymentResult>;
  }> = [];

  // Add configured processors
  if (apiConfig.stripe?.publishableKey && apiConfig.stripe?.secretKey) {
    processors.push({
      name: 'stripe',
      process: processStripePayment
    });
  }

  if (
    apiConfig.braintree?.merchantId &&
    apiConfig.braintree?.publicKey &&
    apiConfig.braintree?.privateKey
  ) {
    processors.push({
      name: 'braintree',
      process: processBraintreePayment
    });
  }

  if (
    apiConfig.square?.applicationId &&
    apiConfig.square?.accessToken &&
    apiConfig.square?.locationId
  ) {
    processors.push({
      name: 'square',
      process: processSquarePayment
    });
  }

  if (apiConfig.paypal?.clientId && apiConfig.paypal?.clientSecret) {
    processors.push({
      name: 'paypal',
      process: processPayPalPayment
    });
  }

  if (processors.length === 0) {
    throw new Error('No hay procesadores de pago configurados');
  }

  // Initialize processing status for all processors
  processors.forEach(processor => {
    onUpdate({
      processor: processor.name.charAt(0).toUpperCase() + processor.name.slice(1),
      status: 'processing',
      message: 'Procesando...',
      timestamp: Date.now()
    });
  });

  // Process all payments in parallel
  const results = await Promise.allSettled(
    processors.map(processor =>
      processor.process(cardData, apiConfig[processor.name])
        .then(result => {
          onUpdate(result);
          return result;
        })
        .catch(error => {
          const errorResult: PaymentResult = {
            processor: processor.name.charAt(0).toUpperCase() + processor.name.slice(1),
            status: 'error',
            message: 'Error al procesar pago',
            error: error.message,
            timestamp: Date.now()
          };
          onUpdate(errorResult);
          return errorResult;
        })
    )
  );

  return results.map(result =>
    result.status === 'fulfilled' ? result.value : result.reason
  );
}
