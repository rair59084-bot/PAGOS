import { useState, useEffect } from 'react';
import { CreditCard, Lock, CheckCircle2, AlertCircle } from 'lucide-react';

interface PaymentFormProps {
  onSubmit: (cardData: CardData) => void;
  isProcessing: boolean;
}

export interface CardData {
  cardNumber: string;
  cardName: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  amount: string;
}

interface DetectedData {
  cardNumber?: string;
  expiry?: string;
  cvv?: string;
  name?: string;
}

export function PaymentForm({ onSubmit, isProcessing }: PaymentFormProps) {
  const [cardInput, setCardInput] = useState('');
  const [amount, setAmount] = useState('');
  const [detectedData, setDetectedData] = useState<DetectedData>({});
  const [cardData, setCardData] = useState<CardData>({
    cardNumber: '',
    cardName: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    amount: ''
  });

  const detectCardInfo = (text: string): DetectedData => {
    const detected: DetectedData = {};

    // Detectar número de tarjeta (13-19 dígitos, pueden estar separados por espacios o guiones)
    const cardNumberRegex = /\b(\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}|\d{13,19})\b/;
    const cardMatch = text.match(cardNumberRegex);
    if (cardMatch) {
      detected.cardNumber = cardMatch[1].replace(/[\s-]/g, '');
    }

    // Detectar CVV (3 o 4 dígitos que no sean parte del número de tarjeta)
    const cvvRegex = /\b(\d{3,4})\b/g;
    const cvvMatches = Array.from(text.matchAll(cvvRegex));
    if (cvvMatches.length > 0) {
      // El CVV suele ser el último grupo de 3-4 dígitos que no sea parte de la tarjeta
      for (let i = cvvMatches.length - 1; i >= 0; i--) {
        const match = cvvMatches[i][1];
        if (match.length <= 4 && (!detected.cardNumber || !detected.cardNumber.includes(match))) {
          detected.cvv = match;
          break;
        }
      }
    }

    // Detectar fecha de expiración (MM/YY, MM/YYYY, MM-YY, MM-YYYY, MMYY, MMYYYY)
    const expiryRegex = /\b(0[1-9]|1[0-2])[\s/-]?(\d{2}|\d{4})\b/;
    const expiryMatch = text.match(expiryRegex);
    if (expiryMatch) {
      detected.expiry = `${expiryMatch[1]}/${expiryMatch[2]}`;
    }

    // Detectar nombre (palabras que contengan solo letras, mínimo 2 palabras)
    const nameRegex = /\b([A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)+)\b/;
    const nameMatch = text.match(nameRegex);
    if (nameMatch) {
      detected.name = nameMatch[1].toUpperCase();
    }

    return detected;
  };

  useEffect(() => {
    const detected = detectCardInfo(cardInput);
    setDetectedData(detected);

    // Actualizar cardData con los valores detectados
    setCardData(prev => ({
      ...prev,
      cardNumber: detected.cardNumber || '',
      cvv: detected.cvv || '',
      cardName: detected.name || '',
      expiryMonth: detected.expiry ? detected.expiry.split('/')[0] : '',
      expiryYear: detected.expiry ? detected.expiry.split('/')[1] : '',
      amount: amount
    }));
  }, [cardInput, amount]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(cardData);
  };

  const isDataComplete = detectedData.cardNumber && detectedData.expiry && detectedData.cvv && detectedData.name && amount;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-blue-100 rounded-lg">
          <CreditCard className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold">Información de Pago</h2>
          <p className="text-sm text-gray-600">Pega o escribe todos los datos de la tarjeta</p>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Monto</label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
          <input
            type="number"
            step="0.01"
            min="0.01"
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">
          Datos de la Tarjeta
          <span className="ml-2 text-xs text-gray-500 font-normal">
            (Número, Fecha MM/YY, CVV, Nombre)
          </span>
        </label>
        <textarea
          value={cardInput}
          onChange={(e) => setCardInput(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[120px] font-mono text-sm"
          placeholder="Ejemplo:&#10;4532 1234 5678 9010&#10;12/25&#10;123&#10;JUAN PEREZ&#10;&#10;O todo en una línea:&#10;4532123456789010 12/25 123 JUAN PEREZ"
        />
        <p className="text-xs text-gray-500 mt-1">
          Puedes pegar toda la información de la tarjeta en cualquier formato. El sistema detectará automáticamente cada campo.
        </p>
      </div>

      {/* Vista previa de datos detectados */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-2">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Datos Detectados:</h3>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2">
            {detectedData.cardNumber ? (
              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-gray-400 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <div className="text-xs text-gray-600">Número de Tarjeta</div>
              <div className={`text-sm font-mono truncate ${detectedData.cardNumber ? 'text-green-700' : 'text-gray-400'}`}>
                {detectedData.cardNumber
                  ? detectedData.cardNumber.replace(/(\d{4})(?=\d)/g, '$1 ')
                  : 'No detectado'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {detectedData.expiry ? (
              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-gray-400 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <div className="text-xs text-gray-600">Fecha de Expiración</div>
              <div className={`text-sm font-mono ${detectedData.expiry ? 'text-green-700' : 'text-gray-400'}`}>
                {detectedData.expiry || 'No detectado'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {detectedData.cvv ? (
              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-gray-400 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <div className="text-xs text-gray-600">CVV</div>
              <div className={`text-sm font-mono ${detectedData.cvv ? 'text-green-700' : 'text-gray-400'}`}>
                {detectedData.cvv || 'No detectado'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {detectedData.name ? (
              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-gray-400 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <div className="text-xs text-gray-600">Nombre del Titular</div>
              <div className={`text-sm truncate ${detectedData.name ? 'text-green-700' : 'text-gray-400'}`}>
                {detectedData.name || 'No detectado'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={isProcessing || !isDataComplete}
        className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
      >
        <Lock className="w-4 h-4" />
        {isProcessing ? 'Procesando...' : isDataComplete ? 'Procesar Pago' : 'Completa los datos de la tarjeta'}
      </button>

      <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
        <Lock className="w-4 h-4" />
        <span>Conexión segura y encriptada</span>
      </div>
    </form>
  );
}
