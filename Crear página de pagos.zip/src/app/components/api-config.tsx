import { useState } from 'react';
import { Settings, Eye, EyeOff, CheckCircle2, XCircle } from 'lucide-react';

export interface ApiConfig {
  stripe?: {
    publishableKey: string;
    secretKey: string;
  };
  braintree?: {
    merchantId: string;
    publicKey: string;
    privateKey: string;
  };
  square?: {
    applicationId: string;
    accessToken: string;
    locationId: string;
  };
  paypal?: {
    clientId: string;
    clientSecret: string;
  };
}

interface ApiConfigProps {
  config: ApiConfig;
  onChange: (config: ApiConfig) => void;
}

export function ApiConfiguration({ config, onChange }: ApiConfigProps) {
  const [showKeys, setShowKeys] = useState<{ [key: string]: boolean }>({});
  const [expanded, setExpanded] = useState<{ [key: string]: boolean }>({
    stripe: false,
    braintree: false,
    square: false,
    paypal: false
  });

  const toggleShowKey = (key: string) => {
    setShowKeys(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleExpanded = (processor: string) => {
    setExpanded(prev => ({ ...prev, [processor]: !prev[processor] }));
  };

  const isConfigured = (processor: keyof ApiConfig): boolean => {
    const processorConfig = config[processor];
    if (!processorConfig) return false;
    return Object.values(processorConfig).every(value => value && value.trim() !== '');
  };

  const configuredCount = Object.keys(config).filter(key => isConfigured(key as keyof ApiConfig)).length;

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-3 bg-purple-100 rounded-lg">
            <Settings className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Configuración de APIs</h2>
            <p className="text-sm text-gray-600">
              {configuredCount > 0
                ? `${configuredCount} procesador${configuredCount > 1 ? 'es' : ''} configurado${configuredCount > 1 ? 's' : ''}`
                : 'Solo para testing local - En producción se usan variables de entorno'}
            </p>
          </div>
        </div>
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-xs text-blue-800">
            <strong>ℹ️ Nota:</strong> Cuando despliegues en Vercel, las credenciales se configuran como <strong>Environment Variables</strong> en el dashboard de Vercel.
            Esta sección es solo para testing local.
          </p>
        </div>
      </div>

      {/* Stripe */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => toggleExpanded('stripe')}
          className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <span className="font-semibold">Stripe</span>
            {isConfigured('stripe') && <CheckCircle2 className="w-5 h-5 text-green-600" />}
          </div>
          <span className="text-sm text-gray-500">{expanded.stripe ? '▲' : '▼'}</span>
        </button>
        {expanded.stripe && (
          <div className="p-4 space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1">Publishable Key</label>
              <div className="relative">
                <input
                  type={showKeys['stripe-pub'] ? 'text' : 'password'}
                  value={config.stripe?.publishableKey || ''}
                  onChange={(e) => onChange({
                    ...config,
                    stripe: { ...config.stripe!, publishableKey: e.target.value }
                  })}
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                  placeholder="pk_test_..."
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey('stripe-pub')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showKeys['stripe-pub'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Secret Key</label>
              <div className="relative">
                <input
                  type={showKeys['stripe-sec'] ? 'text' : 'password'}
                  value={config.stripe?.secretKey || ''}
                  onChange={(e) => onChange({
                    ...config,
                    stripe: { ...config.stripe!, secretKey: e.target.value }
                  })}
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                  placeholder="sk_test_..."
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey('stripe-sec')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showKeys['stripe-sec'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Braintree */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => toggleExpanded('braintree')}
          className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <span className="font-semibold">Braintree</span>
            {isConfigured('braintree') && <CheckCircle2 className="w-5 h-5 text-green-600" />}
          </div>
          <span className="text-sm text-gray-500">{expanded.braintree ? '▲' : '▼'}</span>
        </button>
        {expanded.braintree && (
          <div className="p-4 space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1">Merchant ID</label>
              <input
                type="text"
                value={config.braintree?.merchantId || ''}
                onChange={(e) => onChange({
                  ...config,
                  braintree: { ...config.braintree!, merchantId: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                placeholder="your_merchant_id"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Public Key</label>
              <input
                type="text"
                value={config.braintree?.publicKey || ''}
                onChange={(e) => onChange({
                  ...config,
                  braintree: { ...config.braintree!, publicKey: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                placeholder="your_public_key"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Private Key</label>
              <div className="relative">
                <input
                  type={showKeys['braintree-priv'] ? 'text' : 'password'}
                  value={config.braintree?.privateKey || ''}
                  onChange={(e) => onChange({
                    ...config,
                    braintree: { ...config.braintree!, privateKey: e.target.value }
                  })}
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                  placeholder="your_private_key"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey('braintree-priv')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showKeys['braintree-priv'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Square */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => toggleExpanded('square')}
          className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <span className="font-semibold">Square</span>
            {isConfigured('square') && <CheckCircle2 className="w-5 h-5 text-green-600" />}
          </div>
          <span className="text-sm text-gray-500">{expanded.square ? '▲' : '▼'}</span>
        </button>
        {expanded.square && (
          <div className="p-4 space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1">Application ID</label>
              <input
                type="text"
                value={config.square?.applicationId || ''}
                onChange={(e) => onChange({
                  ...config,
                  square: { ...config.square!, applicationId: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                placeholder="sandbox-sq0idb-..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Access Token</label>
              <div className="relative">
                <input
                  type={showKeys['square-token'] ? 'text' : 'password'}
                  value={config.square?.accessToken || ''}
                  onChange={(e) => onChange({
                    ...config,
                    square: { ...config.square!, accessToken: e.target.value }
                  })}
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                  placeholder="EAAAl..."
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey('square-token')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showKeys['square-token'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Location ID</label>
              <input
                type="text"
                value={config.square?.locationId || ''}
                onChange={(e) => onChange({
                  ...config,
                  square: { ...config.square!, locationId: e.target.value }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                placeholder="L..."
              />
            </div>
          </div>
        )}
      </div>

      {/* PayPal */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => toggleExpanded('paypal')}
          className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <span className="font-semibold">PayPal</span>
            {isConfigured('paypal') && <CheckCircle2 className="w-5 h-5 text-green-600" />}
          </div>
          <span className="text-sm text-gray-500">{expanded.paypal ? '▲' : '▼'}</span>
        </button>
        {expanded.paypal && (
          <div className="p-4 space-y-3">
            <div className="mb-3 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-800">
              <strong>Importante:</strong> Usa credenciales de <strong>Sandbox</strong> de <a href="https://developer.paypal.com/dashboard" target="_blank" rel="noopener noreferrer" className="underline">developer.paypal.com</a>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Client ID (Sandbox)</label>
              <input
                type="text"
                value={config.paypal?.clientId || ''}
                onChange={(e) => onChange({
                  ...config,
                  paypal: { ...config.paypal!, clientId: e.target.value.trim() }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm font-mono"
                placeholder="AV... (empieza con A)"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Client Secret (Sandbox)</label>
              <div className="relative">
                <input
                  type={showKeys['paypal-secret'] ? 'text' : 'password'}
                  value={config.paypal?.clientSecret || ''}
                  onChange={(e) => onChange({
                    ...config,
                    paypal: { ...config.paypal!, clientSecret: e.target.value.trim() }
                  })}
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm font-mono"
                  placeholder="EL... (empieza con E)"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey('paypal-secret')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showKeys['paypal-secret'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {configuredCount === 0 && (
        <div className="flex items-center gap-2 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <XCircle className="w-5 h-5 text-yellow-600 flex-shrink-0" />
          <p className="text-sm text-yellow-800">
            Debes configurar al menos 1 procesador de pago para procesar transacciones
          </p>
        </div>
      )}
    </div>
  );
}
